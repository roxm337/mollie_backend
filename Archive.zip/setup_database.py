#!/usr/bin/env python3
"""
Database setup script for Mollie Backend
Run this script to initialize your database
"""

import asyncio
import os
import sys
from pathlib import Path

# Add the app directory to Python path
sys.path.append(str(Path(__file__).parent))

from app.db import init_db, engine
from app.models import Payment
from sqlmodel import SQLModel

async def setup_database():
    """Initialize the database and create tables"""
    print("🗄️  Setting up MySQL database...")
    
    try:
        # Create all tables
        await init_db()
        print("✅ Database tables created successfully!")
        
        # Test connection
        async with engine.begin() as conn:
            from sqlalchemy import text
            result = await conn.execute(text("SELECT 1"))
            print("✅ Database connection test successful!")
            
        print("\n🎉 MySQL database setup complete!")
        print("You can now start your FastAPI server with: python3 -m uvicorn app.main:app --reload")
        
    except Exception as e:
        print(f"❌ Database setup failed: {e}")
        print("\nTroubleshooting:")
        print("1. Make sure MySQL is running")
        print("2. Check your DATABASE_URL in .env file")
        print("3. Ensure the database exists")
        print("4. Verify your credentials are correct")
        print("5. Make sure aiomysql is installed: pip install aiomysql")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(setup_database())
