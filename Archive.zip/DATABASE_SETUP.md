# 🗄️ Database Setup Guide

This guide will help you set up PostgreSQL for your Mollie backend application.

## 📋 Prerequisites

- Python 3.9+
- PostgreSQL 12+ (or Docker)
- All dependencies installed (`pip install -r requirements.txt`)

## 🚀 Quick Setup Options

### Option 1: Local PostgreSQL (Recommended for Development)

#### 1. Install PostgreSQL
```bash
# macOS (using Homebrew)
brew install postgresql
brew services start postgresql

# Ubuntu/Debian
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql

# Windows
# Download from https://www.postgresql.org/download/windows/
```

#### 2. Create Database and User
```bash
# Connect to PostgreSQL
psql -U postgres

# Create database and user
CREATE DATABASE mollie_payments;
CREATE USER mollie_user WITH PASSWORD 'your_secure_password';
GRANT ALL PRIVILEGES ON DATABASE mollie_payments TO mollie_user;
\q
```

#### 3. Create Environment File
Create a `.env` file in the project root:
```bash
# Database Configuration
DATABASE_URL=postgresql+asyncpg://mollie_user:your_secure_password@localhost:5432/mollie_payments

# Mollie Configuration
MOLLIE_API_KEY=your_mollie_api_key_here
MOLLIE_API_BASE=https://api.mollie.com/v2

# Service Configuration
SERVICE_API_KEY=your_secure_service_api_key_here
FRONTEND_RETURN_URL=https://your-frontend.com/pay-return

# Environment
ENV=development
```

### Option 2: Docker PostgreSQL (Easy Setup)

#### 1. Create Docker Compose File
Create `docker-compose.yml`:
```yaml
version: '3.8'
services:
  postgres:
    image: postgres:15
    environment:
      POSTGRES_DB: mollie_payments
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: password
    ports:
      - "5432:5432"
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
```

#### 2. Start PostgreSQL
```bash
docker-compose up -d
```

#### 3. Environment Configuration
Use this DATABASE_URL in your `.env`:
```
DATABASE_URL=postgresql+asyncpg://postgres:password@localhost:5432/mollie_payments
```

### Option 3: Cloud PostgreSQL (Production)

#### Popular Options:
- **Supabase**: Free tier available
- **Railway**: Simple deployment
- **Neon**: Serverless PostgreSQL
- **AWS RDS**: Enterprise-grade
- **Google Cloud SQL**: Managed service

## 🛠️ Database Initialization

### Method 1: Using Setup Script (Recommended)
```bash
# Make sure your .env file is configured
python3 setup_database.py
```

### Method 2: Using Alembic Migrations (Production)
```bash
# Create initial migration
python3 -m alembic revision --autogenerate -m "Initial migration"

# Apply migrations
python3 -m alembic upgrade head
```

### Method 3: Manual Setup
```bash
# Start your FastAPI app (it will create tables automatically)
python3 -m uvicorn app.main:app --reload
```

## 🔧 Database Management Commands

### Alembic Commands
```bash
# Create a new migration
python3 -m alembic revision --autogenerate -m "Description of changes"

# Apply migrations
python3 -m alembic upgrade head

# Rollback to previous migration
python3 -m alembic downgrade -1

# Check current migration status
python3 -m alembic current

# Show migration history
python3 -m alembic history
```

### Database Connection Test
```bash
# Test database connection
python3 -c "
import asyncio
from app.db import engine

async def test():
    async with engine.begin() as conn:
        result = await conn.execute('SELECT 1')
        print('✅ Database connection successful!')

asyncio.run(test())
"
```

## 🐛 Troubleshooting

### Common Issues:

1. **Connection Refused**
   - Check if PostgreSQL is running
   - Verify port 5432 is open
   - Check firewall settings

2. **Authentication Failed**
   - Verify username/password in DATABASE_URL
   - Check user permissions
   - Ensure user has access to the database

3. **Database Does Not Exist**
   - Create the database manually
   - Check database name in DATABASE_URL

4. **Module Import Errors**
   - Ensure you're in the project directory
   - Check Python path
   - Verify all dependencies are installed

### Debug Commands:
```bash
# Check PostgreSQL status
brew services list | grep postgresql  # macOS
sudo systemctl status postgresql     # Linux

# Connect to database manually
psql -U postgres -d mollie_payments

# Check database tables
\dt

# Check table structure
\d payments
```

## 📊 Database Schema

Your database will have the following table:

### `payments` table:
- `id`: Primary key (auto-increment)
- `mollie_id`: Mollie payment ID (indexed)
- `amount`: Payment amount (float)
- `currency`: Currency code (default: EUR)
- `description`: Payment description
- `status`: Payment status (indexed)
- `checkout_url`: Mollie checkout URL
- `created_at`: Creation timestamp
- `updated_at`: Last update timestamp
- `payment_metadata`: JSON metadata (alias: metadata)
- `idempotency_key`: Idempotency key for duplicate prevention

## 🚀 Next Steps

1. ✅ Set up your database using one of the options above
2. ✅ Create your `.env` file with proper configuration
3. ✅ Run the database setup script
4. ✅ Start your FastAPI server: `python3 -m uvicorn app.main:app --reload`
5. ✅ Test your API endpoints

## 📝 Environment Variables Reference

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | PostgreSQL connection string | `postgresql+asyncpg://user:pass@host:port/db` |
| `MOLLIE_API_KEY` | Your Mollie API key | `test_xxxxxxxxxxxxxxxx` |
| `SERVICE_API_KEY` | API key for service authentication | `your-secure-api-key` |
| `FRONTEND_RETURN_URL` | Frontend return URL after payment | `https://yourapp.com/payment/return` |
| `ENV` | Environment (development/production) | `development` |

---

Need help? Check the troubleshooting section or create an issue in the repository.
