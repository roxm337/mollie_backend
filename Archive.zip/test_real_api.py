#!/usr/bin/env python3
"""
Real Mollie API Testing Script
This script helps you test your backend with real Mollie API responses
"""

import asyncio
import httpx
import json
import os
from datetime import datetime

# Configuration
API_BASE_URL = "http://localhost:8000"

# Try to load from .env file first
def load_env():
    env_vars = {}
    try:
        with open('.env', 'r') as f:
            for line in f:
                if line.strip() and not line.startswith('#') and '=' in line:
                    key, value = line.strip().split('=', 1)
                    env_vars[key] = value
    except FileNotFoundError:
        pass
    return env_vars

env_vars = load_env()
MOLLIE_API_KEY = os.getenv("MOLLIE_API_KEY", env_vars.get("MOLLIE_API_KEY", "your_mollie_api_key_here"))
SERVICE_API_KEY = os.getenv("SERVICE_API_KEY", env_vars.get("SERVICE_API_KEY", "your_secure_service_api_key_here"))

class MollieBackendTester:
    def __init__(self):
        self.headers = {
            "Content-Type": "application/json",
            "X-API-KEY": SERVICE_API_KEY
        }
        self.created_payments = []
    
    async def test_payment_creation(self):
        """Test creating a real payment with Mollie"""
        print("🧪 Testing Payment Creation with Real Mollie API...")
        
        test_payments = [
            {
                "amount": "5.99",
                "currency": "EUR",
                "description": "Test Payment - Coffee",
                "metadata": {"order_id": f"order_{int(datetime.now().timestamp())}"}
            },
            {
                "amount": "25.50",
                "currency": "EUR", 
                "description": "Test Payment - Book",
                "metadata": {"order_id": f"order_{int(datetime.now().timestamp()) + 1}"}
            },
            {
                "amount": "100.00",
                "currency": "USD",
                "description": "Test Payment - International",
                "metadata": {"order_id": f"order_{int(datetime.now().timestamp()) + 2}"}
            }
        ]
        
        async with httpx.AsyncClient() as client:
            for i, payment_data in enumerate(test_payments, 1):
                print(f"\n📝 Test Payment {i}: {payment_data['description']}")
                
                try:
                    response = await client.post(
                        f"{API_BASE_URL}/payments/create",
                        headers=self.headers,
                        json=payment_data,
                        timeout=30.0
                    )
                    
                    if response.status_code == 200:
                        result = response.json()
                        self.created_payments.append(result)
                        print(f"✅ Payment created successfully!")
                        print(f"   Mollie ID: {result['mollie_id']}")
                        print(f"   Status: {result['status']}")
                        print(f"   Checkout URL: {result['checkout_url']}")
                    else:
                        print(f"❌ Payment creation failed: {response.status_code}")
                        print(f"   Error: {response.text}")
                        
                except Exception as e:
                    print(f"❌ Error creating payment: {e}")
    
    async def test_payment_status(self):
        """Test retrieving payment status"""
        print("\n🔍 Testing Payment Status Retrieval...")
        
        if not self.created_payments:
            print("❌ No payments to test status for")
            return
        
        async with httpx.AsyncClient() as client:
            for payment in self.created_payments:
                mollie_id = payment['mollie_id']
                print(f"\n📊 Checking status for payment: {mollie_id}")
                
                try:
                    response = await client.get(
                        f"{API_BASE_URL}/payments/status/{mollie_id}",
                        headers=self.headers,
                        timeout=30.0
                    )
                    
                    if response.status_code == 200:
                        result = response.json()
                        print(f"✅ Status retrieved successfully!")
                        print(f"   Status: {result['status']}")
                        print(f"   Amount: {result['amount']['value']} {result['amount']['currency']}")
                        print(f"   Description: {result['description']}")
                    else:
                        print(f"❌ Status retrieval failed: {response.status_code}")
                        print(f"   Error: {response.text}")
                        
                except Exception as e:
                    print(f"❌ Error retrieving status: {e}")
    
    async def test_webhook_simulation(self):
        """Test webhook handling"""
        print("\n🔔 Testing Webhook Handling...")
        
        if not self.created_payments:
            print("❌ No payments to test webhook for")
            return
        
        async with httpx.AsyncClient() as client:
            for payment in self.created_payments:
                mollie_id = payment['mollie_id']
                print(f"\n📨 Simulating webhook for payment: {mollie_id}")
                
                webhook_data = {
                    "id": mollie_id
                }
                
                try:
                    response = await client.post(
                        f"{API_BASE_URL}/payments/webhook",
                        json=webhook_data,
                        timeout=30.0
                    )
                    
                    if response.status_code == 200:
                        result = response.json()
                        print(f"✅ Webhook processed successfully!")
                        print(f"   Response: {result}")
                    else:
                        print(f"❌ Webhook processing failed: {response.status_code}")
                        print(f"   Error: {response.text}")
                        
                except Exception as e:
                    print(f"❌ Error processing webhook: {e}")
    
    async def test_error_handling(self):
        """Test error handling with invalid data"""
        print("\n🚨 Testing Error Handling...")
        
        error_tests = [
            {
                "name": "Invalid Amount",
                "data": {
                    "amount": "invalid",
                    "currency": "EUR",
                    "description": "Invalid amount test"
                }
            },
            {
                "name": "Missing Required Field",
                "data": {
                    "amount": "10.00",
                    "description": "Missing currency test"
                }
            },
            {
                "name": "Invalid Currency",
                "data": {
                    "amount": "10.00",
                    "currency": "INVALID",
                    "description": "Invalid currency test"
                }
            }
        ]
        
        async with httpx.AsyncClient() as client:
            for test in error_tests:
                print(f"\n🧪 Testing: {test['name']}")
                
                try:
                    response = await client.post(
                        f"{API_BASE_URL}/payments/create",
                        headers=self.headers,
                        json=test['data'],
                        timeout=30.0
                    )
                    
                    print(f"   Status: {response.status_code}")
                    if response.status_code != 200:
                        print(f"   ✅ Error handled correctly: {response.text}")
                    else:
                        print(f"   ⚠️  Unexpected success: {response.json()}")
                        
                except Exception as e:
                    print(f"   ✅ Exception handled: {e}")
    
    async def check_database_records(self):
        """Check what was saved to the database"""
        print("\n💾 Checking Database Records...")
        
        try:
            import subprocess
            result = subprocess.run([
                "psql", "-U", "mollie_user", "-d", "mollie_payments", 
                "-c", "SELECT mollie_id, amount, currency, status, description, created_at FROM payment ORDER BY created_at DESC LIMIT 5;"
            ], capture_output=True, text=True)
            
            if result.returncode == 0:
                print("✅ Database records:")
                print(result.stdout)
            else:
                print(f"❌ Database query failed: {result.stderr}")
                
        except Exception as e:
            print(f"❌ Error checking database: {e}")
    
    async def run_all_tests(self):
        """Run all tests"""
        print("🚀 Starting Real Mollie API Tests")
        print("=" * 50)
        
        # Check if API keys are set
        if MOLLIE_API_KEY == "your_mollie_api_key_here":
            print("❌ Please set your real Mollie API key in the environment")
            print("   export MOLLIE_API_KEY='your_actual_api_key'")
            return
        
        if SERVICE_API_KEY == "your_secure_service_api_key_here":
            print("❌ Please set your service API key in the environment")
            print("   export SERVICE_API_KEY='your_service_api_key'")
            return
        
        print(f"🔑 Using Mollie API Key: {MOLLIE_API_KEY[:10]}...")
        print(f"🔑 Using Service API Key: {SERVICE_API_KEY[:10]}...")
        
        # Run tests
        await self.test_payment_creation()
        await self.test_payment_status()
        await self.test_webhook_simulation()
        await self.test_error_handling()
        await self.check_database_records()
        
        print("\n🎉 All tests completed!")
        print(f"📊 Created {len(self.created_payments)} payments for testing")

async def main():
    tester = MollieBackendTester()
    await tester.run_all_tests()

if __name__ == "__main__":
    asyncio.run(main())
