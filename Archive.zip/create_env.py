#!/usr/bin/env python3
"""
Environment file creation script
This script helps you create a .env file with the necessary configuration
"""

import os
from pathlib import Path

def create_env_file():
    """Create a .env file with default configuration"""
    
    env_content = """# Database Configuration
# Choose one of the following options:

# Option 1: Local PostgreSQL
DATABASE_URL=postgresql+asyncpg://mollie_user:your_secure_password@localhost:5432/mollie_payments

# Option 2: Docker PostgreSQL
# DATABASE_URL=postgresql+asyncpg://postgres:password@localhost:5432/mollie_payments

# Option 3: Cloud PostgreSQL (replace with your actual values)
# DATABASE_URL=postgresql+asyncpg://user:pass@host:port/dbname

# Mollie Configuration
MOLLIE_API_KEY=your_mollie_api_key_here
MOLLIE_API_BASE=https://api.mollie.com/v2

# Service Configuration
SERVICE_API_KEY=your_secure_service_api_key_here
FRONTEND_RETURN_URL=https://your-frontend.com/pay-return

# Environment
ENV=development
"""

    env_file = Path(".env")
    
    if env_file.exists():
        print("⚠️  .env file already exists!")
        response = input("Do you want to overwrite it? (y/N): ")
        if response.lower() != 'y':
            print("❌ Cancelled. No changes made.")
            return
    
    try:
        with open(env_file, 'w') as f:
            f.write(env_content)
        
        print("✅ .env file created successfully!")
        print("\n📝 Next steps:")
        print("1. Edit .env file with your actual database credentials")
        print("2. Add your Mollie API key")
        print("3. Set a secure SERVICE_API_KEY")
        print("4. Update FRONTEND_RETURN_URL")
        print("5. Run: python3 setup_database.py")
        
    except Exception as e:
        print(f"❌ Error creating .env file: {e}")

if __name__ == "__main__":
    create_env_file()
