-- Database initialization script for Mollie Backend
-- This script runs when the PostgreSQL container starts for the first time

-- Create a dedicated user for the application
CREATE USER mollie_user WITH PASSWORD 'mollie_password';

-- Grant necessary privileges
GRANT ALL PRIVILEGES ON DATABASE mollie_payments TO mollie_user;

-- Create extensions that might be useful
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- Set timezone
SET timezone = 'UTC';
