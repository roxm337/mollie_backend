#!/usr/bin/env python3
"""
Setup script for real Mollie API testing
"""

import os
import sys
from pathlib import Path

def setup_real_testing():
    print("🔧 Setting up Real Mollie API Testing")
    print("=" * 40)
    
    # Check if .env exists
    env_file = Path(".env")
    if not env_file.exists():
        print("❌ .env file not found. Creating one...")
        create_env_file()
    
    print("\n📝 Current .env configuration:")
    with open(env_file, 'r') as f:
        for line in f:
            if line.strip() and not line.startswith('#'):
                key, value = line.strip().split('=', 1)
                if 'KEY' in key or 'PASSWORD' in key:
                    print(f"   {key}={value[:10]}...")
                else:
                    print(f"   {key}={value}")
    
    print("\n🔑 To test with real Mollie API:")
    print("1. Get your API key from https://my.mollie.com/")
    print("2. Update your .env file with real values:")
    print("   MOLLIE_API_KEY=your_real_api_key_here")
    print("   SERVICE_API_KEY=your_secure_service_key")
    print("3. Run: python3 test_real_api.py")
    
    print("\n🧪 For testing, you can also run:")
    print("   export MOLLIE_API_KEY='your_key'")
    print("   export SERVICE_API_KEY='your_service_key'")
    print("   python3 test_real_api.py")

def create_env_file():
    """Create a basic .env file"""
    env_content = """# Database Configuration - Local PostgreSQL
DATABASE_URL=postgresql+asyncpg://mollie_user:mollie_password@localhost:5432/mollie_payments

# Mollie Configuration - REPLACE WITH YOUR REAL API KEY
MOLLIE_API_KEY=your_mollie_api_key_here
MOLLIE_API_BASE=https://api.mollie.com/v2

# Service Configuration - REPLACE WITH YOUR SECURE KEY
SERVICE_API_KEY=your_secure_service_api_key_here
FRONTEND_RETURN_URL=https://your-frontend.com/pay-return

# Environment
ENV=development
"""
    
    with open(".env", "w") as f:
        f.write(env_content)
    
    print("✅ .env file created")

if __name__ == "__main__":
    setup_real_testing()
