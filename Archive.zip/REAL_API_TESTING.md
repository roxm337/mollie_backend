# 🧪 Real Mollie API Testing Guide

This guide will help you test your Mollie backend with real API responses.

## 🔑 Prerequisites

1. **Mollie Account**: Sign up at [mollie.com](https://www.mollie.com/)
2. **API Keys**: Get your API keys from [Mollie Dashboard](https://my.mollie.com/)
3. **Backend Running**: Your FastAPI server should be running

## 🚀 Quick Start

### 1. Get Your Mollie API Keys

1. Go to [Mollie Dashboard](https://my.mollie.com/)
2. Navigate to **Developers → API Keys**
3. Copy your API key:
   - **Test key**: starts with `test_` (for testing)
   - **Live key**: starts with `live_` (for production)

### 2. Set Up Environment

```bash
# Option 1: Update .env file
nano .env
# Replace the placeholder values with your real keys

# Option 2: Set environment variables
export MOLLIE_API_KEY="test_your_actual_api_key_here"
export SERVICE_API_KEY="your_secure_service_key_here"
```

### 3. Run Real API Tests

```bash
# Run comprehensive tests
python3 test_real_api.py

# Or run individual tests
python3 -c "
import asyncio
from test_real_api import MollieBackendTester
tester = MollieBackendTester()
asyncio.run(tester.test_payment_creation())
"
```

## 🧪 Test Scenarios

### 1. Payment Creation Tests
- ✅ Create payments with different amounts
- ✅ Test different currencies (EUR, USD, GBP)
- ✅ Test with metadata
- ✅ Test error handling

### 2. Payment Status Tests
- ✅ Retrieve payment status
- ✅ Check payment details
- ✅ Verify Mollie API integration

### 3. Webhook Tests
- ✅ Simulate webhook calls
- ✅ Test webhook processing
- ✅ Verify database updates

### 4. Error Handling Tests
- ✅ Invalid amounts
- ✅ Missing required fields
- ✅ Invalid currencies
- ✅ API key validation

## 📊 Expected Results

### Successful Payment Creation
```json
{
  "mollie_id": "tr_xxxxxxxxxxxxx",
  "checkout_url": "https://www.mollie.com/checkout/select-method/tr_xxxxxxxxxxxxx",
  "status": "open"
}
```

### Payment Status Response
```json
{
  "mollie_id": "tr_xxxxxxxxxxxxx",
  "status": "open",
  "amount": {
    "value": "10.50",
    "currency": "EUR"
  },
  "description": "Test Payment",
  "checkout_url": "https://www.mollie.com/checkout/select-method/tr_xxxxxxxxxxxxx",
  "raw": {
    // Full Mollie API response
  }
}
```

### Webhook Response
```json
{
  "status": "accepted"
}
```

## 🔍 Database Verification

After running tests, check your database:

```bash
# Connect to database
psql -U mollie_user -d mollie_payments

# View recent payments
SELECT mollie_id, amount, currency, status, description, created_at 
FROM payment 
ORDER BY created_at DESC 
LIMIT 10;

# Check specific payment
SELECT * FROM payment WHERE mollie_id = 'tr_xxxxxxxxxxxxx';
```

## 🚨 Troubleshooting

### Common Issues

1. **"Invalid X-API-KEY"**
   - Check your SERVICE_API_KEY in .env
   - Restart your FastAPI server after changing .env

2. **"Mollie API Error"**
   - Verify your MOLLIE_API_KEY is correct
   - Check if you're using test vs live keys appropriately

3. **"Database Connection Error"**
   - Ensure PostgreSQL is running
   - Check DATABASE_URL in .env

4. **"Payment Creation Failed"**
   - Check Mollie API key permissions
   - Verify amount format (use strings like "10.50")

### Debug Commands

```bash
# Check server logs
tail -f /var/log/your-app.log

# Test database connection
python3 setup_database.py

# Check environment variables
python3 -c "from app.config import settings; print(f'DB: {settings.database_url[:20]}...')"

# Test Mollie API directly
curl -H "Authorization: Bearer your_api_key" https://api.mollie.com/v2/payments
```

## 🎯 Test Checklist

- [ ] Mollie API key configured
- [ ] Service API key configured
- [ ] FastAPI server running
- [ ] Database connected
- [ ] Payment creation working
- [ ] Payment status retrieval working
- [ ] Webhook handling working
- [ ] Database records created
- [ ] Error handling working
- [ ] All tests passing

## 🔄 Continuous Testing

For ongoing testing, you can:

1. **Automated Tests**: Run `python3 test_real_api.py` regularly
2. **Manual Testing**: Use the Swagger UI at `http://localhost:8000/docs`
3. **Webhook Testing**: Use tools like ngrok to expose your local webhook endpoint
4. **Database Monitoring**: Set up alerts for failed payments

## 📈 Production Readiness

Before going live:

1. ✅ Test with real Mollie live API keys
2. ✅ Test webhook endpoints with real Mollie webhooks
3. ✅ Verify database performance with large datasets
4. ✅ Test error scenarios thoroughly
5. ✅ Set up monitoring and logging
6. ✅ Configure proper security settings

---

**Need Help?** Check the troubleshooting section or create an issue in the repository.
